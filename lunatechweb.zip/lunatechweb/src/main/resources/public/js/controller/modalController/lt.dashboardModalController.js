'use strict';
app.controller('DashboardModalController',['$scope','dashboardService','DTOptionsBuilder','DTColumnBuilder','$q','$compile','commonDTService', function($scope,dashboardService,DTOptionsBuilder,DTColumnBuilder,$q,$compile,commonDTService,$modalInstance) {
	$scope.dc = $scope.$resolve.detail;
	$scope.parent = $scope.$resolve.scopeDetail;
    //$scope.dc.message=false;

	$scope.dtOptionsRunway =commonDTService.getDTOptionBy3Params($scope,$scope.dc,'Runway');
	$scope.dtColumnsRunway = [
	          DTColumnBuilder.newColumn('id').withTitle('Runway_id'),
	          DTColumnBuilder.newColumn('airport_ref').withTitle('airport_ref'),
	          DTColumnBuilder.newColumn('airport_ident').withTitle('airport_ident'),
	          DTColumnBuilder.newColumn('length_ft').withTitle('length_ft'),
	          DTColumnBuilder.newColumn('width_ft').withTitle('width_ft'),
	          DTColumnBuilder.newColumn('surface').withTitle('surface'),
	          DTColumnBuilder.newColumn('lighted').withTitle('lighted'),
	          DTColumnBuilder.newColumn('closed').withTitle('closed'),
	          DTColumnBuilder.newColumn('le_ident').withTitle('le_ident'),
	          DTColumnBuilder.newColumn('le_latitude_deg').withTitle('le_latitude_deg'),
	          DTColumnBuilder.newColumn('le_longitude_deg').withTitle('le_longitude_deg'),
	          DTColumnBuilder.newColumn('le_elevation_ft').withTitle('le_elevation_ft'),
	          DTColumnBuilder.newColumn('le_heading_degT').withTitle('le_heading_degT'),
	          DTColumnBuilder.newColumn('le_displaced_threshold_ft').withTitle('le_displaced_threshold_ft'),
	          DTColumnBuilder.newColumn('he_ident').withTitle('he_ident'),
	          DTColumnBuilder.newColumn('he_latitude_deg').withTitle('he_latitude_deg'),
	          DTColumnBuilder.newColumn('he_elevation_ft').withTitle('he_elevation_ft'),
	          DTColumnBuilder.newColumn('he_heading_degT').withTitle('he_heading_degT'),
	          DTColumnBuilder.newColumn('he_displaced_threshold_ft').withTitle('he_displaced_threshold_ft'),
	];
	

  
 
	/*function createdRow(row, data, dataIndex) {
		  	$compile(angular.element(row).contents())($scope);
   };*/
    
	 /*  resetSowData .start */
	 $scope.reset = function() {
		  $scope.dc = {};
	};
	 /*  resetSowData .end */
	
	 /*  resetSowData .start */
	 $scope.closePage = function() {
		$scope.$close();
	};
	     /*  resetSowData .end */
}]);//controller function ends

