
package com.lt.web.ai.dao.impl;


import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.lt.web.ai.dao.CountryDao;
import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.model.CountryEntity;
import com.lt.web.ai.repo.CountryRepository;
import com.lt.web.ai.vo.CountryVO;



@Repository("countryDao")
public class CountryDaoImpl implements CountryDao {

	@Resource
	private CountryRepository countryRepository;

	@Override
	public CountryEntity getCountryDetailsByCode(String code) throws LTException {
		return countryRepository.findByCode(code);
	}
	
	@Override
	public CountryEntity getCountryDetailsByName(String name) throws LTException {
		return countryRepository.findByName(name);
	}

	@Override
	public boolean saveCountryData(List<CountryVO> countryVOs) throws LTException {
		boolean status=false;
		List<CountryEntity> countryEntities=new ArrayList<>();
		for(CountryVO countryVO : countryVOs) {
			CountryEntity countryEntity = new CountryEntity();
			BeanUtils.copyProperties(countryVO, countryEntity);
			countryEntity.setId(Long.parseLong(countryVO.getId()));
			countryEntities.add(countryEntity);
			status=true;
		}
		countryRepository.save(countryEntities);
		countryRepository.flush();
		return status;
	}
	@Override
	public List<String> getCountryNameStartsWith(String countryNameInitial) throws LTException {
		return countryRepository.findByNameStartingWithIgnoreCase(countryNameInitial);
	}
	
	@Override
	public List<String> getCountryCodeStartsWith(String countryCodeInitial) throws LTException {
		return countryRepository.findByCodeStartingWithIgnoreCase(countryCodeInitial);
	}

	
	
	
}