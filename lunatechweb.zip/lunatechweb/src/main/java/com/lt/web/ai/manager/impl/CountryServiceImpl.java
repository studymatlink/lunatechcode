
package com.lt.web.ai.manager.impl;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lt.web.ai.dao.CountryDao;
import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.manager.CountryService;
import com.lt.web.ai.model.CountryEntity;
import com.lt.web.ai.vo.CountryVO;


@Service("countryService")
public class CountryServiceImpl implements CountryService{
	
	@Autowired
    private CountryDao countryDao;

	@Override
	public List<String> getCountryNameStartsWith(String countryNameInitial) throws LTException {
		return countryDao.getCountryNameStartsWith(countryNameInitial);
	}

	@Override
	public List<String> getCountryCodeStartsWith(String countryCodeInitial) throws LTException {
		return countryDao.getCountryCodeStartsWith(countryCodeInitial);
	}

	@Override
	public CountryEntity getCountryDetailsByCode(String code) throws LTException {
		return countryDao.getCountryDetailsByCode(code);
	}

	@Override
	public CountryEntity getCountryDetailsByName(String name) throws LTException {
		return countryDao.getCountryDetailsByName(name);
	}



	
	

	
}
