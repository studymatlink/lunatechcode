package com.lt.web.ai.controller;


import java.util.List;

/*import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.manager.CountryService;
import com.lt.web.ai.manager.RunwayService;
import com.lt.web.ai.vo.CountVO;


@RestController
public class RunwayController {
	
	@Autowired
	private	RunwayService runwayService;
	
	@GetMapping(value = "/runway/getTop10CommonRunwayIdentification")
	public List<CountVO> getTop10CommonRunwayIdentification() {
		try {
			return runwayService.getTop10CommonRunwayIdentification();
		} catch (LTException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
}
