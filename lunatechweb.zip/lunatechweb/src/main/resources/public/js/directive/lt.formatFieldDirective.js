'use strict';
app.directive('formatDate', function($filter) {

			return {
				require : 'ngModel',
				link : function(scope, elem, attr, modelCtrl) {
					modelCtrl.$formatters.push(function(modelValue) {
						//console.log("new Date(modelValue)===>"+new Date(modelValue));
						return new Date(modelValue);
						//return $filter('date')(new Date(modelValue),'yyyy-MM-dd HH:mm:ss Z');
					})
				}
			}
		});// controller function ends

app.directive('formatNumber', function() {

	return {
		require : 'ngModel',
		link : function(scope, elem, attr, modelCtrl) {
			modelCtrl.$formatters.push(function(modelValue) {
				return Number(modelValue);
			})
		}
	}
});// controller function ends