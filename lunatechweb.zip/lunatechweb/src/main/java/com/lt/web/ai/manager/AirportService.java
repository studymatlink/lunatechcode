
package com.lt.web.ai.manager;

import java.util.List;

import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.vo.AirportVO;
import com.lt.web.ai.vo.CountVO;
import com.lt.web.ai.vo.QueryVO;

public interface AirportService {
	List<AirportVO> getAirportsByCountryCode(String countryCode) throws LTException;
	List<QueryVO> getAirportsWithRunwayByCountryCode(String countryCode) throws LTException;
	List<CountVO> getTop10CountryWithHighestAirportCount() throws LTException;
	List<CountVO> getTop10CountryWithLowestAirportCount() throws LTException;
}
