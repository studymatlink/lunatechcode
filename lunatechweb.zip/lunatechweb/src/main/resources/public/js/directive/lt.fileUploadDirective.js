app.directive("fileUpload", function() {
	  return {
	    require: "ngModel",
	    link: function postLink(scope,elem,attrs,ngModel) {
	      elem.on("change", function(e) {
	        var files = elem[0].files;
	        //console.log("files====>"+files[0]);
	        ngModel.$setViewValue(files[0]);
	        
	      })
	    }
	  }
	});
app.directive("fileUploadDyn", function() {
	  return {
	    require: "ngModel",
	    link: function postLink(scope,elem,attrs,ngModel) {
	      elem.on("change", function(e) {
	        var files = elem[0].files;
	        ngModel.$setViewValue(files[0]);
	        
	      })
	    }
	  }
	});
app.directive("fileUploadExcel", function() {
    return {
       	restrict: 'EA',
        scope:{
        	modelName :'@modelName',
        	showFileContent :'@showFileContent',
        	fileSaveMethod :'@fileSaveMethod',
        	fileContentName :'@fileContentName'
        },
        //bindToController: true,
        controller: 'FileUploadController', 
       	templateUrl : "html/common/fileUploadExcel.html",
        link: function($scope, elm, attrs, ctrl) {
        	$scope.fileType='EXCEL';
        	$scope.fileContentName=$scope.fileContentName.trim() ;
        },
        
    };
});
app.directive("fileUploadDoc", function() {
    return {
       	restrict: 'EA',
        scope:{
        	modelName :'@modelName',
        	//showFileContent :'@showFileContent',
        	fileSaveMethod :'@fileSaveMethod',
        	fileContentName :'@fileContentName'
        },
        //bindToController: true,
        controller: 'FileUploadController', 
       	templateUrl : "html/common/fileUploadDoc.html",
        link: function($scope, elm, attrs, ctrl) {
        	$scope.fileType='DOC';
        },
    };
});
