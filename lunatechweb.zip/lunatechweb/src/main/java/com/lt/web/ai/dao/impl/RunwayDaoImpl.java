
package com.lt.web.ai.dao.impl;


import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.lt.web.ai.dao.RunwayDao;
import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.model.AirportEntity;
import com.lt.web.ai.model.RunwayEntity;
import com.lt.web.ai.repo.RunwayRepository;
import com.lt.web.ai.vo.AirportVO;
import com.lt.web.ai.vo.RunwayVO;



@Repository("runwayDao")
public class RunwayDaoImpl implements RunwayDao {

	@Resource
	private RunwayRepository runwayRepository;

	@Override
	public boolean saveRunwayData(List<RunwayVO> runwayVOs) throws LTException {
		boolean status=false;
		List<RunwayEntity> runwayEntities=new ArrayList<>();
		for(RunwayVO runwayVO : runwayVOs) {
			RunwayEntity runwayEntity = new RunwayEntity();
			BeanUtils.copyProperties(runwayVO, runwayEntity);
			runwayEntity.setId(Long.parseLong(runwayVO.getId()));
			runwayEntity.setAirportRef(runwayVO.getAirport_ref());
			runwayEntity.setAirportIdent(runwayVO.getAirport_ident());
			runwayEntities.add(runwayEntity);
			status=true;
		}
		runwayRepository.save(runwayEntities);
		runwayRepository.flush();
		return status;
	}

	@Override
	public List<RunwayVO> getRunwayDetailsByAirportRefAndIdent(String airportRef, String airportIdent) throws LTException {
		List<RunwayVO> runwayVOs=new ArrayList<>();
		List<RunwayEntity> runwayEntities=runwayRepository.findByAirportRefAndAirportIdent(airportRef, airportIdent);
		if(!CollectionUtils.isEmpty(runwayEntities)) {
			for (RunwayEntity runwayEntity : runwayEntities) {
				RunwayVO runwayVO=new RunwayVO();
				BeanUtils.copyProperties(runwayEntity,runwayVO);
				runwayVO.setId(String.valueOf(runwayEntity.getId()));
				runwayVO.setAirport_ref(runwayEntity.getAirportRef());
				runwayVO.setAirport_ident(runwayEntity.getAirportIdent());
				runwayVOs.add(runwayVO);
			}
			
		}
		
		return runwayVOs;
	}

	@Override
	public List<String> getDistinctRunwaySurfaceDetailsByAirportRef(List<String> airportRef) throws LTException {
		List<String> runwayVOs=new ArrayList<>();
		List<String> surfaceList=runwayRepository.findDistinctSurfaceByAirportRef(airportRef);
		if(!CollectionUtils.isEmpty(surfaceList)) {
			for (String surface : surfaceList) {
				runwayVOs.add(surface);
			}
		}
		return runwayVOs;
	}

	@Override
	public List<Object[]> getTop10CommonRunwayIdentification() throws LTException {
		return runwayRepository.findTop10CommonRunwayIdentification();
	}
}