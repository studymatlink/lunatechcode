package com.lt.web.ai.dao;





import java.util.List;

import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.model.CountryEntity;
import com.lt.web.ai.vo.CountryVO;


public interface CountryDao {
	List<String> getCountryNameStartsWith(String countryNameInitial) throws LTException;
	List<String> getCountryCodeStartsWith(String countryCodeInitial) throws LTException;
	boolean saveCountryData(List<CountryVO> sowContents) throws LTException;
	CountryEntity getCountryDetailsByCode(String code) throws LTException;
	CountryEntity getCountryDetailsByName(String name) throws LTException;
}
