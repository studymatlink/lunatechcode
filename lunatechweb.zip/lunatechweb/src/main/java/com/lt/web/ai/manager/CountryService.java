
package com.lt.web.ai.manager;

import java.util.List;

import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.model.CountryEntity;
import com.lt.web.ai.vo.CountryVO;

public interface CountryService {
	List<String> getCountryNameStartsWith(String countryNameInitial) throws LTException;
	List<String> getCountryCodeStartsWith(String countryCodeInitial) throws LTException;
	CountryEntity getCountryDetailsByCode(String code) throws LTException;
	CountryEntity getCountryDetailsByName(String name) throws LTException;

}
