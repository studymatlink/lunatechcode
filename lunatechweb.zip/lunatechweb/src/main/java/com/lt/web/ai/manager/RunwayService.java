
package com.lt.web.ai.manager;

import java.util.List;

import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.vo.CountVO;
import com.lt.web.ai.vo.RunwayVO;

public interface RunwayService {
	RunwayVO getRunwayDetailsById(Long id) throws LTException;
	List<RunwayVO> getAllRunwayDetails() throws LTException;
	List<String> getRunwayNameStartsWith(String coltManagersName) throws LTException;
	List<RunwayVO> getRunwayDetailsByAirportRefAndIdent(String airportRef, String airportIdent) throws LTException;
	List<String> getDistinctRunwaySurfaceDetailsByAirportRef(List<String> airportRefs) throws LTException;
	List<CountVO> getTop10CommonRunwayIdentification() throws LTException;
	
}
