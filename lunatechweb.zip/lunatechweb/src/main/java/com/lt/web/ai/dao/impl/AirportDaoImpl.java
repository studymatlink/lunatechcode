
package com.lt.web.ai.dao.impl;


import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.lt.web.ai.dao.AirportDao;
import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.model.AirportEntity;
import com.lt.web.ai.repo.AirportRepository;
import com.lt.web.ai.vo.AirportVO;



@Repository("airportDao")
public class AirportDaoImpl implements AirportDao {

	@Resource
	private AirportRepository airportRepository;

	@Override
	public boolean saveAirportData(List<AirportVO> airportVOs) throws LTException {
			boolean status=false;
			List<AirportEntity> airportEntities=new ArrayList<>();
			for(AirportVO airportVO : airportVOs) {
				AirportEntity airportEntity = new AirportEntity();
				BeanUtils.copyProperties(airportVO, airportEntity);
				airportEntity.setId(Long.parseLong(airportVO.getId()));
				airportEntity.setIsoCountry(airportVO.getIso_country());
				airportEntities.add(airportEntity);
				status=true;
			}
			airportRepository.save(airportEntities);
			airportRepository.flush();
			return status;
		
	}

	@Override
	public List<AirportVO> getAirportsByCountryCode(String countryCode) throws LTException {
		List<AirportEntity> airportEntities= airportRepository.findByIsoCountry(countryCode);
		List<AirportVO> airportVOs=new ArrayList<>();
		for(AirportEntity airportEntity : airportEntities) {
			AirportVO airportVO = new AirportVO();
			BeanUtils.copyProperties(airportEntity, airportVO);
			airportVO.setId(String.valueOf(airportEntity.getId()));
			airportVO.setIso_country(airportEntity.getIsoCountry());
			airportVOs.add(airportVO);
		}
		return airportVOs;
	}

	@Override
	public List<Object[]> getTop10CountryWithHighestAirportCount() throws LTException {
		return airportRepository.findTop10CountryWithHighestAirportCount();
	}

	@Override
	public List<Object[]> getTop10CountryWithLowestAirportCount() throws LTException {
		return airportRepository.findTop10CountryWithLowestAirportCount();
	}

}