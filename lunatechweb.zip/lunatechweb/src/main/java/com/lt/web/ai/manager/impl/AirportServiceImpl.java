
package com.lt.web.ai.manager.impl;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.lt.web.ai.dao.AirportDao;
import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.manager.AirportService;
import com.lt.web.ai.manager.RunwayService;
import com.lt.web.ai.repo.AirportRepository;
import com.lt.web.ai.vo.AirportVO;
import com.lt.web.ai.vo.CountVO;
import com.lt.web.ai.vo.QueryVO;
import com.lt.web.ai.vo.RunwayVO;


@Service("airportService")
public class AirportServiceImpl implements AirportService{
	
	@Autowired
    private AirportDao airportDao;
	
	@Autowired
    private RunwayService runwayService;

	@Override
	public List<AirportVO> getAirportsByCountryCode(String countryCode) throws LTException {
		return airportDao.getAirportsByCountryCode(countryCode);
	}

	@Override
	public List<QueryVO> getAirportsWithRunwayByCountryCode(String countryCode) throws LTException {
		List<QueryVO> queryVOs=new ArrayList<>();
		List<AirportVO> airportVOs= airportDao.getAirportsByCountryCode(countryCode);
		for (AirportVO airportVO : airportVOs) {
			QueryVO queryVO=new QueryVO();
			List<RunwayVO> runwayVOs=runwayService.getRunwayDetailsByAirportRefAndIdent(airportVO.getId(), airportVO.getIdent());
			queryVO.setAirportVO(airportVO);
			queryVO.setRunwayVOs(runwayVOs);
			queryVOs.add(queryVO);
		}
		return queryVOs;
	}

	@Override
	public List<CountVO> getTop10CountryWithHighestAirportCount() throws LTException {
		List<CountVO> countVOs=new ArrayList<>();
		List<Object[]> list=airportDao.getTop10CountryWithHighestAirportCount();
		for (Object[] object : list) {
				CountVO countVO=new CountVO();
				countVO.setCountry(String.valueOf(object[0]));
				countVO.setCount(Long.valueOf(String.valueOf(object[1])));
				List<AirportVO> airportVOs= airportDao.getAirportsByCountryCode(countVO.getCountry());
				List<String> airportRefVOs=new ArrayList<>();
				for (AirportVO airportVO : airportVOs) {
					airportRefVOs.add(airportVO.getId());
				}
				List<String> runwayVOList=runwayService.getDistinctRunwaySurfaceDetailsByAirportRef(airportRefVOs);
				countVO.setRunwaySurface(StringUtils.collectionToCommaDelimitedString(runwayVOList));
				countVOs.add(countVO);
		}
		return countVOs;
	}

	@Override
	public List<CountVO> getTop10CountryWithLowestAirportCount() throws LTException {
		List<CountVO> countVOs=new ArrayList<>();
		List<Object[]> list=airportDao.getTop10CountryWithLowestAirportCount();
		for (Object[] object : list) {
				CountVO countVO=new CountVO();
				countVO.setCountry(String.valueOf(object[0]));
				countVO.setCount(Long.valueOf(String.valueOf(object[1])));
				List<AirportVO> airportVOs= airportDao.getAirportsByCountryCode(countVO.getCountry());
				List<String> airportRefVOs=new ArrayList<>();
				for (AirportVO airportVO : airportVOs) {
					airportRefVOs.add(airportVO.getId());
				}
				List<String> runwayVOList=runwayService.getDistinctRunwaySurfaceDetailsByAirportRef(airportRefVOs);
				countVO.setRunwaySurface(StringUtils.collectionToCommaDelimitedString(runwayVOList));
				countVOs.add(countVO);
		}
		return countVOs;
	}
	
	
	
}
