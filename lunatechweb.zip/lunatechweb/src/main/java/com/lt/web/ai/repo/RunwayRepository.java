package com.lt.web.ai.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.model.RunwayEntity;
import com.lt.web.ai.vo.RunwayVO;

public interface RunwayRepository extends JpaRepository<RunwayEntity, Long>{
	 RunwayEntity findById(Long id);
	 List<RunwayEntity> findAllByOrderByIdAsc();
	 List<RunwayEntity> findByAirportRefAndAirportIdent(String airportRef,String airportIdent);
	 @Query("select distinct re.surface from RunwayEntity re where re.airportRef in ?1")
	 List<String> findDistinctSurfaceByAirportRef(List<String> airportRefs);
	 @Query(value="select  le_ident,count(*)as le_ident_count from Runway  group by le_ident ORDER BY le_ident_count DESC LIMIT 10", nativeQuery=true)
	 List<Object[]> findTop10CommonRunwayIdentification() throws LTException;

 }