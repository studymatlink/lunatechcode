/**
 * 
 */
package com.lt.web.ai.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.Year;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.util.ObjectUtils;




/**
 * @author aranjan5
 *
 */
public class DateUtil {
	private static final DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	
	public static Date ConverStringToDateUTC(String date) {
		Date formattedDate =null;
		try {
			if(!ObjectUtils.isEmpty(date)){
			SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			formattedDate=dateFormatter.parse(date); 
			dateFormat.format(formattedDate);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		 return formattedDate;
	}
	
	/*public static Date ConverStringToDate(String date) {
		Date formattedDate =null;
		try {
			if(!ObjectUtils.isEmpty(date)){
			SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
			formattedDate=dateFormatter.parse(date); 
			dateFormat.format(formattedDate);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		 return formattedDate;
	}*/
	
	public static Date ConverStringToDate(String date) {
		Date formattedDate =null;
		try {
			if(!ObjectUtils.isEmpty(date)){
			SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yy");
			formattedDate=dateFormatter.parse(date); 
			dateFormat.format(formattedDate);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		 return formattedDate;
	}
	
	
	public static String ConverDateToString(Date date) {
		String formattedDate =null;
		try {
			if(!ObjectUtils.isEmpty(date)){
				formattedDate=dateFormat.format(date);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return formattedDate;
	}
	
	public static String ConverDateToStringUTC(Date date) {
		String formattedDate =null;
		try {
			if(!ObjectUtils.isEmpty(date)){
				formattedDate= new DateTime(date).withZone(DateTimeZone.UTC).toString();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return formattedDate;
		
		
	}
	
	public static String getCurrentDate() {
		 return dateFormat.format(new Date());
	}
	
	public static String getNextDate() {
		Date sowEndDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(sowEndDate);
		calendar.add(Calendar.DATE, 1);
		sowEndDate = calendar.getTime();
		return dateFormat.format(sowEndDate);
	}
	public static String getPreviousDate() {
       	Date sowEndDate = new Date();
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(sowEndDate); 
		calendar.add(Calendar.DATE, -1);
		sowEndDate = calendar.getTime();
		return dateFormat.format(sowEndDate);
	}
	
	public static long getDifferenceInTime(String documentDate) {
		final String METHOD_NAME = "getDifferenceInTime";
		
		long diff = 0;
		DateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			Date now = new Date();
			Date date = dateformat.parse(documentDate);
			// reset all hours, minutes and seconds to zero on system date
			Calendar startCal = GregorianCalendar.getInstance();
			startCal.setTime(now);
			startCal.set(Calendar.HOUR_OF_DAY, 0);
			startCal.set(Calendar.MINUTE, 0);
			startCal.set(Calendar.SECOND, 0);
			long startTime = startCal.getTimeInMillis();
			// reset all hours, minutes and seconds to zero on document date
			Calendar endCal = GregorianCalendar.getInstance();
			endCal.setTime(date);
			endCal.set(Calendar.HOUR_OF_DAY, 0);
			endCal.set(Calendar.MINUTE, 0);
			endCal.set(Calendar.SECOND, 0);
			long endTime = endCal.getTimeInMillis();
			//diff = (startTime - endTime) / MILLISECONDS_IN_DAY;
		} catch (Exception e) {
			
		}
		return diff;
	}
	
	public static String getSowEndBeforeFifteenDays() {
		Date sowEndDate = new Date();
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(sowEndDate); 
		calendar.add(Calendar.DATE, 15);
		sowEndDate = calendar.getTime();
		return dateFormat.format(sowEndDate);
	}
	public static String getSowEndBeforeTenDays() {
		Date sowEndDate = new Date();
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(sowEndDate); 
		calendar.add(Calendar.DATE, 10);
		sowEndDate = calendar.getTime();
		return dateFormat.format(sowEndDate);
	}
	public static String getSowEndBeforeFiveDays() {
		Date sowEndDate = new Date();
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(sowEndDate); 
		calendar.add(Calendar.DATE, 5);
		sowEndDate = calendar.getTime();
		return dateFormat.format(sowEndDate);
	}
	
	public static String getMobilePassBeforeThreeDays() {
		Date sowEndDate = new Date();
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(sowEndDate); 
		calendar.add(Calendar.DATE, 3);
		sowEndDate = calendar.getTime();
		return dateFormat.format(sowEndDate);
	}
	public static String getMobilePassBeforeTwoDays() {
		Date sowEndDate = new Date();
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(sowEndDate); 
		calendar.add(Calendar.DATE, 2);
		sowEndDate = calendar.getTime();
		return dateFormat.format(sowEndDate);
	}
	
	public static Date ConvertStringToDate(String date) {
		Date formattedDate =null;
		try {
			if(!ObjectUtils.isEmpty(date)){
				formattedDate=dateFormat.parse(date);  
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return formattedDate;
	}
	
	/*public static List<String> getMobilePassDate() {
       	Date sowEndDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(sowEndDate);
		List<String> dateList = new ArrayList<String>();
		Integer mobilePassDaysReminder[] = {15,10,5};
		for (Integer days : mobilePassDaysReminder) {			
			calendar.add(Calendar.DATE, days);
			sowEndDate = calendar.getTime();			
			dateList.add(dateFormat.format(sowEndDate));
			break;
		}		
		return dateList;
	}*/
	
	public static List<String> getMonthsBetweenDate(String startDate,String endDate) {
			List<String> months = new ArrayList<> ();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy", Locale.ENGLISH);
			DateTimeFormatter outPutFormatter = DateTimeFormatter.ofPattern ( "MMM-yyyy" , Locale.ENGLISH );
		    YearMonth startDateParse = YearMonth.parse(startDate, formatter);
		    YearMonth endDateParse= YearMonth.parse(endDate, formatter);
		   /* System.out.println("startDateParse===>"+startDateParse);
		    System.out.println("endDateParse===>"+endDateParse);
		    System.out.println("compare===>"+startDateParse.isBefore(endDateParse));*/
		    while(startDateParse.isBefore(endDateParse) || startDateParse.equals(endDateParse)) {
		    	String month=startDateParse.format(outPutFormatter);
		    	months.add(month.toUpperCase());
		        //System.out.println(month);
		        startDateParse = startDateParse.plusMonths(1);
		        //System.out.println("startDateParse in while===>"+startDateParse);
		    }
		    return months;
	}
	
	public static List<String> getMonthsBetweenDate(Date startDate,Date endDate) {
		List<String> months = new ArrayList<> ();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy", Locale.ENGLISH);
		DateTimeFormatter outPutFormatter = DateTimeFormatter.ofPattern ( "MMMM-yyyy" , Locale.ENGLISH );
	    YearMonth startDateParse = YearMonth.parse(DateUtil.ConverDateToString(startDate), formatter);
	    YearMonth endDateParse= YearMonth.parse(DateUtil.ConverDateToString(endDate), formatter);
	    while(startDateParse.isBefore(endDateParse)|| startDateParse.equals(endDateParse)) {
	    	String month=startDateParse.format(outPutFormatter);
	    	months.add(month.toUpperCase());
	       // System.out.println(month);
	        startDateParse = startDateParse.plusMonths(1);
	    }
	    return months;
	}
	
	public static String getCurrentMonth() {
	    Month month= YearMonth.now().getMonth();
	    return  month.name();
	}
	
	public static Month getMonthsForDate(Date date) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy", Locale.ENGLISH);
		LocalDate currentDate = LocalDate.parse(DateUtil.ConverDateToString(date), formatter); // 2016-06-17 
		//int dom = currentDate.getDayOfMonth(); // 17 
		Month m = currentDate.getMonth(); // JUNE 
		//int y = currentDate.getYear(); // 2016
		return m;
	}
	
	public static Month getMonthsForDate(String date) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy", Locale.ENGLISH);
		//DateTimeFormatter outPutFormatter = DateTimeFormatter.ofPattern ( "MMM" , Locale.ENGLISH );
		LocalDate currentDate = LocalDate.parse(date, formatter); // 2016-06-17 
		//int dom = currentDate.getDayOfMonth(); // 17 
		Month m = currentDate.getMonth(); // JUNE 
		//int y = currentDate.getYear(); // 2016
		return m;
	}
	
	public static Month convertStringToMonth(String month) {
		return Month.valueOf(month);
	}
	
	public static int getTotalWorkingbetweenDates(Date startDate,Date endDate) {
		int workingDays = 0; 
		try{
			Calendar start = Calendar.getInstance();
		    start.setTime(startDate);
		    Calendar end = Calendar.getInstance();
		    end.setTime(endDate);
			while(!start.after(end)){
				int day = start.get(Calendar.DAY_OF_WEEK);
		        if ((day != Calendar.SATURDAY) && (day != Calendar.SUNDAY))
		        workingDays++;
		        //System.out.println(workingDays);//moved
		        start.add(Calendar.DATE, 1);//removed comment tags
			}
		 
		}catch(Exception e)	{
		 e.printStackTrace();
		}
		return workingDays;
	}	
	
	public static int getTotalWorkingDaysForMonthYear(Month month,String year) {
		String startDate=DateUtil.getFirstDateForMonthYear(month, year);
		//System.out.println("startDate====>"+startDate);
		Date lastDate=DateUtil.getLastDateOfMonth(startDate);
		return getTotalWorkingbetweenDates(DateUtil.ConverStringToDate(startDate),lastDate);
	}
	
	public static String getFirstDateForMonthYear(Month month,String year) {
		String monthValue="";
		if(month.getValue()<=9) {
			monthValue="0"+month.getValue();
		}else {
			monthValue=String.valueOf(month.getValue());
		}
		String startDate=monthValue+"/01/"+year;
		System.out.println("startDate====>"+startDate);
		
		return startDate;
	}
	
	public static String getLastDateForMonthYear(Month month,String year) {
		String monthValue="";
		if(month.getValue()<=9) {
			monthValue="0"+month.getValue();
		}else {
			monthValue=String.valueOf(month.getValue());
		}
		
		String lastDate=monthValue+"/"+month.length(Year.of(Integer.parseInt(year)).isLeap())+"/"+year;
		System.out.println("LastDate====>"+lastDate);
		
		return lastDate;
	}
	
	public static Date getLastDateOfMonth(String startDate){
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy", Locale.ENGLISH); 
		LocalDate date = LocalDate.parse(startDate, dateFormat);
		LocalDate lastDate=null;
		if(date.isLeapYear()) {
			lastDate = date.withDayOfMonth(date.getMonth().maxLength());
		}else {
			lastDate = date.withDayOfMonth(date.getMonth().minLength());
		}
		System.out.println("getLastDateOfMonth===>"+lastDate.format(dateFormat));
		return DateUtil.ConverStringToDate(lastDate.format(dateFormat));
	}
	
	public static Date getLastDateOfMonth(Date startDate){
		//String dateString = "01/13/2012";
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy", Locale.ENGLISH); 
		//DateTimeFormatter outPutFormatter = DateTimeFormatter.ofPattern ( "mm-dd-yyyy" , Locale.ENGLISH );
		LocalDate date = LocalDate.parse(DateUtil.ConverDateToString(startDate), dateFormat);
		LocalDate lastDate=null;
		if(date.isLeapYear()) {
			lastDate = date.withDayOfMonth(date.getMonth().maxLength());
		}else {
			lastDate = date.withDayOfMonth(date.getMonth().minLength());
		}
		System.out.println("getLastDateOfMonth===>"+lastDate.format(dateFormat));
		return DateUtil.ConverStringToDate(lastDate.format(dateFormat));
	}
	
	public static Date getFirstDateOfCurrentMonth(){
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy", Locale.ENGLISH); 
		LocalDate today = LocalDate.now();
		LocalDate firstDay = today.withDayOfMonth(1);
		return DateUtil.ConverStringToDate(firstDay.format(dateFormat));
	}
	
	public static Date getLastDateOfCurrentMonth(){
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy", Locale.ENGLISH); 
		LocalDate today = LocalDate.now();
		LocalDate lastDay =today.withDayOfMonth(today.lengthOfMonth());
		return DateUtil.ConverStringToDate(lastDay.format(dateFormat));
	}
	
	public static int getCurrentYear(){
		LocalDate today = LocalDate.now();
		return today.getYear();
	}
	public static int getNextYear(){
		LocalDate today = LocalDate.now();
		LocalDate nextYear = today.plusYears(1);
		return nextYear.getYear();
	}
	
	public static Map<String,List<String>> getQuarterMap() {
		Map<String,List<String>> quraterMap=new TreeMap<>();
		List<String> q1List=new ArrayList<>();
		List<String> q2List=new ArrayList<>();
		List<String> q3List=new ArrayList<>();
		List<String> q4List=new ArrayList<>();
		q1List.add("APRIL");
		q1List.add("MAY");
		q1List.add("JUNE");
		q2List.add("JULY");
		q2List.add("AUGUST");
		q2List.add("SEPTEMBER");
		q3List.add("OCTOBER");
		q3List.add("NOVEMBER");
		q3List.add("DECEMBER");
		q4List.add("JANUARY");
		q4List.add("FEBRUARY");
		q4List.add("MARCH");
		quraterMap.put("Q1", q1List);
		quraterMap.put("Q2", q2List);
		quraterMap.put("Q3", q3List);
		quraterMap.put("Q4", q4List);
		return quraterMap;
	}
	
	public static List<String> getMonthList() {
		List<String> monthList=new ArrayList<>();
		monthList.add("JANUARY");
		monthList.add("FEBRUARY");
		monthList.add("MARCH");
		monthList.add("APRIL");
		monthList.add("MAY");
		monthList.add("JUNE");
		monthList.add("JULY");
		monthList.add("AUGUST");
		monthList.add("SEPTEMBER");
		monthList.add("OCTOBER");
		monthList.add("NOVEMBER");
		monthList.add("DECEMBER");
		
		return monthList;
	}
	
	public static int getFinYear(String month) {
		int finYear=0;
		List<String> q4MonthList=new ArrayList<>();
		q4MonthList.add("JANUARY");
		q4MonthList.add("FEBRUARY");
		q4MonthList.add("MARCH");
		//if(q4MonthList.contains(DateUtil.getCurrentMonth())) {
		if(q4MonthList.contains(month)) {
			finYear=DateUtil.getCurrentYear();
		}else {
			finYear=DateUtil.getCurrentYear()-1;
		}
		return finYear;
	}
	
	//public static int monthTotalWorkingDaysByStartAndEndDate(ResourceEntity resourceEntity,String monthYear){
	public static int totalWorkingDaysByStartAndEndDateAndMonthYear(Date startDate,Date endDate,String monthYear){
		String[] my=monthYear.split("-");
		String month=my[0];
		String year=my[1];
		//Month allocationStartMonth=DateUtil.getMonthsForDate(startDate);
		//Month allocationEndtMonth=DateUtil.getMonthsForDate(endDate);
		Month startMonth=DateUtil.getMonthsForDate(startDate);
		Month endMonth=DateUtil.getMonthsForDate(endDate);
		Month reportMonth=DateUtil.convertStringToMonth(month);
		int startMonthComapre=startMonth.compareTo(reportMonth);
		int endMonthComapre=endMonth.compareTo(reportMonth);
		int totalWorkingDays=0;
		
		if(startMonth.equals(endMonth)) {
			totalWorkingDays=DateUtil.getTotalWorkingbetweenDates(startDate,endDate);
		}else {
			if(startMonthComapre==0) {
				Date endDateOfMonth=DateUtil.getLastDateOfMonth(startDate);
				totalWorkingDays=DateUtil.getTotalWorkingbetweenDates(startDate,endDateOfMonth);
			}else if(startMonthComapre<=-1) {
				if(endMonthComapre==0) {
					Date startDateOfMonth=DateUtil.ConverStringToDate(DateUtil.getFirstDateForMonthYear(endMonth, year));
					totalWorkingDays=DateUtil.getTotalWorkingbetweenDates(startDateOfMonth,endDate);
				}else if(endMonthComapre>=1) {
					totalWorkingDays=DateUtil.getTotalWorkingDaysForMonthYear(reportMonth,year);
				}else if(endMonthComapre<=-1) {
					totalWorkingDays=DateUtil.getTotalWorkingDaysForMonthYear(reportMonth,year);
				}
			}else if(startMonthComapre>=1) {
				if(endMonthComapre==0) {
					Date startDateOfMonth=DateUtil.ConverStringToDate(DateUtil.getFirstDateForMonthYear(endMonth, year));
					totalWorkingDays=DateUtil.getTotalWorkingbetweenDates(startDateOfMonth,endDate);
				}else if(endMonthComapre>=1) {
					totalWorkingDays=DateUtil.getTotalWorkingDaysForMonthYear(reportMonth,year);
				}
			}
		}
		return totalWorkingDays;
	}
	
	public static void main(String[] args) {
		//System.out.println(DateUtil.getMonthsBetweenDate("02/01/2017","02/28/2017"));
		//System.out.println(DateUtil.getMonthsForDate("02/01/2017"));
		/*Month sm=DateUtil.convertStringToMonth("NOVEMBER");
		Month em=DateUtil.convertStringToMonth("FEBRUARY");*/
		//System.out.println(sm.compareTo(em));
		//System.out.println(sm.minLength());
		//System.out.println(em.maxLength());
		//System.out.println(DateUtil.getLastDateOfMonth("03/01/2017"));
		//System.out.println(DateUtil.getTotalWorkingDaysForMonth(sm, "2017"));
		System.out.println(DateUtil.getNextYear());
	}
}
