package com.lt.web.ai.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.poiji.internal.annotation.ExcelCell;

import groovy.transform.EqualsAndHashCode;
import lombok.Data;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown=true)
public class CountryVO extends BaseVO{
	@ExcelCell(0) 
	private String id;
	@ExcelCell(1) 
	private String code;
	@ExcelCell(2) 
	private String name;
	@ExcelCell(3) 
	private String continent;
	@ExcelCell(4) 
	private String wikipedia_link;
	@ExcelCell(5) 
	private String keywords;
	
}