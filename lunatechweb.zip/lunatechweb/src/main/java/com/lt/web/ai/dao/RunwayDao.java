package com.lt.web.ai.dao;





import java.util.List;

import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.model.RunwayEntity;
import com.lt.web.ai.vo.AirportVO;
import com.lt.web.ai.vo.RunwayVO;


public interface RunwayDao {
	boolean saveRunwayData(List<RunwayVO> sowContents) throws LTException;
	List<RunwayVO> getRunwayDetailsByAirportRefAndIdent(String airportRef,String airportIdent) throws LTException;
	List<String> getDistinctRunwaySurfaceDetailsByAirportRef(List<String> airportRefs) throws LTException;
	List<Object[]> getTop10CommonRunwayIdentification() throws LTException;
}
