'use strict';
app.factory('dashboardService', ['$http','$q','commonutil',function($http, $q,commonutil) {
   return {
	   getCountryNameStartsWith : function(data) {
			  return commonutil.httpCall('./country/getCountryNameStartsWith','GET',{data:data},'');
		},
		
		getCountryCodeStartsWith : function(data) {
			  return commonutil.httpCall('./country/getCountryCodeStartsWith','GET',{data:data},'');
		},

		getAirports : function(countryName,countryCode) {
			console.log("countryCodeser===>"+countryCode);
			return commonutil.httpCall('./airport/getAirports','GET',{countryName:countryName,countryCode:countryCode},'');
		},
		
		getTop10CountryWithHighestAirportCount : function() {
			console.log("getTop10CountryWithHighestAirportCount===>");
			return commonutil.httpCall('./airport/getTop10CountryWithHighestAirportCount','GET',{},'');
		},
		
		getTop10CountryWithLowestAirportCount : function() {
			console.log("====getTop10CountryWithLowestAirportCount==");
			return commonutil.httpCall('./airport/getTop10CountryWithLowestAirportCount','GET',{},'');
		},
		
		getTop10CommonRunwayIdentification : function() {
			console.log("====getTop10CountryWithLowestAirportCount==");
			return commonutil.httpCall('./runway/getTop10CommonRunwayIdentification','GET',{},'');
		},
	};
	
}]);
