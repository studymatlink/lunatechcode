package com.lt.web.ai.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import groovy.transform.EqualsAndHashCode;
import lombok.Data;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown=true)
public class CountVO {
	private String country;
	private Long count;
	private String runwaySurface;
	private String runwayIdent;
	
	/*public CountVO(String country, Long count) {
	    this.country = country;
	    this.count  = count;
	  }*/
	
}