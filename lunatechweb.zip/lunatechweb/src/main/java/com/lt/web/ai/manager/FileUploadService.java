
package com.lt.web.ai.manager;



import java.io.File;
import java.util.List;

import com.lt.web.ai.vo.AirportVO;
import com.lt.web.ai.vo.CountryVO;
import com.lt.web.ai.vo.RunwayVO;


public interface FileUploadService {
	List<?> getFileContent(File file,String fileUploadName,String fileType);
	byte[] getDocFileContent(File file,String fileUploadName);
	String countryImport(List<CountryVO> fileContent);
	String airportImport(List<AirportVO> fileContent);
	String runwayImport(List<RunwayVO> fileContent);
}
