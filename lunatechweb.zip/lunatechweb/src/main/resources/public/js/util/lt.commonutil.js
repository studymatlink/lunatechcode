'use strict';
app.factory('commonutil', ['$http', '$q', function($http, $q) {
  return {
			 /*
			  * params value can be set as {user_id: user.id},if it is blank pass as {}
			  * If data is blank then pass as ''
			  *$q, A service that helps you run functions asynchronously, and use their return values
			  * (or exceptions) when they are done processing.
			  * A new instance of deferred is constructed by calling $q.defer().
			  * The purpose of the deferred object is to expose the associated Promise instance as 
			  * well as APIs that can be used for signaling the successful or unsuccessful completion,
			  *  as well as the status of the task.
			  * */
		        httpCall:function(url,method,params,data) {
		        	var deferred = $q.defer();
		        	console.log("=====js url method is in httpCall====="+url);
		            $http({
		            	 url: url,    
		            	 method: method,
		                 data: data,
		                 params:params,
		                 cache: false
		         
		                }).then(
		                    	function (response) {
		                    		deferred.resolve(response.data);
		                    		console.log(response.data)
		                      }, 
		                      function (errorResponse) {
		                    	  deferred.reject(errorResponse);
		                          console.log(errorResponse.statusText);
		                          console.log(errorResponse);
		                      }
		                  );
		            return deferred.promise;
		        },
  
		  fileHttpCall:function(url,method,params,data) {
		  	var deferred = $q.defer();
		  	var fileFormData = new FormData();
			fileFormData.append('file', data);
		  	console.log("=====js url method is in fileHttpCall====="+url);
		      $http({
		      	   url: url,    
		      	   method: method,
		           data: fileFormData,
		           params:params,
		           transformRequest: angular.identity,
		           headers: {
                       'Content-Type': undefined
                   },
                   
		          // enctype : 'multipart/form-data',
		          /* processData : false, 
				   contentType : false,
				   timeout : 600000,*/
		           cache: false
		          }).then(
		              	function (response) {
		              		deferred.resolve(response.data);
		              		console.log("file response ====>"+response)
		              		console.log("file response data====>"+response.data)
		                }, 
		                function (errorResponse) {
		              	  deferred.reject(errorResponse);
		                    console.log(errorResponse.statusText);
		                    console.log(errorResponse);
		                }
		            );
		      return deferred.promise;
		  },
		        
		        fileHttpCallByte:function(url,method,params,data) {
				  	var deferred = $q.defer();
				  	var fileFormData = new FormData();
					fileFormData.append('file', data);
				  	console.log("=====js url method is in fileHttpCall====="+url);
				      $http({
				      	   url: url,    
				      	   method: method,
				           data: fileFormData,
				           params:params,
				           transformRequest: angular.identity,
				           headers: {
				               'Content-type': undefined,
				               'responseType': 'arraybuffer'
				           },
				           cache: false
				          }).then(
				              	function (response) {
				              		deferred.resolve(response.data);
				              		/*console.log("file response ====>"+response)
				              		console.log("file response data====>"+response.data)*/
				                }, 
				                function (errorResponse) {
				              	  deferred.reject(errorResponse);
				                    console.log(errorResponse.statusText);
				                    console.log(errorResponse);
				                }
				            );
				      return deferred.promise;
				  },
				  
				  downloadDochttpCall:function(url,method,params,data) {
			        	var deferred = $q.defer();
			        	console.log("=====js url method is in downloadDochttpCall====="+url);
			            $http({
			            	 url: url,    
			            	 method: method,
			                 data: data,
			                 params:params,
			                 cache: false,
			               //responseType: 'arraybuffer'
			                 /*headers: {
					               'Content-type': 'application/json charset=UTF-8',
					               'Accept': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
					           }*/
			                }).then(
			                    	function (response) {
			                    		deferred.resolve(response.data);
			                    		console.log(response.data)
			                      }, 
			                      function (errorResponse) {
			                    	  deferred.reject(errorResponse);
			                          console.log(errorResponse.statusText);
			                          console.log(errorResponse);
			                      }
			                  );
			            return deferred.promise;
			        },
			        
			  	  downloadDocArrayHttpCall:function(url,method,params,data) {
			        	var deferred = $q.defer();
			        	console.log("=====js url method is in downloadDochttpCall====="+url);
			            $http({
			            	 url: url,    
			            	 method: method,
			                 data: data,
			                 params:params,
			                 cache: false,
			                 responseType: 'arraybuffer',
			                 headers: {
					               'Content-type': 'application/json charset=UTF-8',
					               'Accept': 'application/msword;charset=UTF-8'
					           }
			                }).then(
			                    	function (response) {
			                    		deferred.resolve(response.data);
			                    		console.log(response.data)
			                      }, 
			                      function (errorResponse) {
			                    	  deferred.reject(errorResponse);
			                          console.log(errorResponse.statusText);
			                          console.log(errorResponse);
			                      }
			                  );
			            return deferred.promise;
			        },
		        
  };//end of return
  
  
	  
	  
}]);
