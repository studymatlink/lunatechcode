/**
 * 
 */
package com.lt.web.ai.vo;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

/**
 * @author aranjan5
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown=true)
public class SelectListVO {
    private String id;
    private String name;

}
