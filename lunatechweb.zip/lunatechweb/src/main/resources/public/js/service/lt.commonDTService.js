'use strict';
app.factory('commonDTService', ['$q','DTOptionsBuilder','DTColumnBuilder','$compile','$filter','sharedService', function($q,DTOptionsBuilder,DTColumnBuilder,$compile,$filter,sharedService) {
	return {
	  	  getDTOptionBy3Params: function(scope,data,title) {
	  		//console.log("scope in service111====>"+scope);
	  		 sharedService.setData(scope);
	  		  return DTOptionsBuilder.fromFnPromise(function() {
				//console.log("fileContent ====>" +data);
		        var defer = $q.defer();
		        defer.resolve(data);
		        return defer.promise;
		       }).withOption('responsive', true)
		      .withOption('autoWidth', false)
			 .withPaginationType('full_numbers')
			 .withDOM('frtip')
	         .withOption('createdRow', createdRow)
		     .withOption('deferRender', true)
		     .withBootstrap()
		     .withOption('scrollX', 'auto')      
			 .withOption('scrollCollapse', true)
		     .withButtons([
		   	 /* {
		   		  extend:    'colvis',
		   		  text:      '<i class="fa fa-colvis-o"></i> ColVis',
		   		  titleAttr: 'ColVis'
		   	  },*/
		   	  {
		   		  extend:    'print',
		   		  text:      '<i class="fa fa-print" aria-hidden="true"></i> Print',
		   		  titleAttr: 'Print'
		   	  },
		   	  {
		   		  extend:    'excelHtml5',
		   		  text:      '<i class="fa fa-file-text-o"></i> Excel',
		   		  titleAttr: 'Excel',
		   		  title :title,
		   		 // exportOptions: {columns:':visible'},
		   	  },
		      {
		   		  extend:    'pdfHtml5',
		   		  text:      '<i class="fa fa-file-pdf-o"></i> Pdf',
		   		  titleAttr: 'Pdf',
		   		  orientation: 'landscape',
		   		  pageSize: 'A4',
     	   		  title :title,
                }
		     ]
		   );
		  },//end of function
		  
		  getDTOptionBy3ParamsNoScroll: function(scope,data,title) {
		  		console.log("scope in service111====>"+scope);
		  		//controllerScope=scope;
		  		 sharedService.setData(scope);
		  		  return DTOptionsBuilder.fromFnPromise(function() {
					console.log("fileContent ====>" +data);
			        var defer = $q.defer();
			        defer.resolve(data);
			        return defer.promise;
			       }).withOption('responsive', true)
			      .withOption('autoWidth', false)
				 .withPaginationType('full_numbers')
				 .withDOM('frtip')
		         .withOption('createdRow', createdRow)
			     .withOption('deferRender', true)
			     .withBootstrap()
//			     .withOption('scrollX', 'auto')      
				//.withOption('scrollCollapse', true)
			     .withButtons([
			   	  /*{
			   		  extend:    'colvis',
			   		  text:      '<i class="fa fa-colvis-o"></i> ColVis',
			   		  titleAttr: 'ColVis'
			   	  },*/
			   	  {
			   		  extend:    'print',
			   		  text:      '<i class="fa fa-print" aria-hidden="true"></i> Print',
			   		  titleAttr: 'Print'
			   	  },
			   	  {
			   		  extend:    'excelHtml5',
			   		  text:      '<i class="fa fa-file-text-o"></i> Excel',
			   		  titleAttr: 'Excel',
			   		  title :title,
			   		 // exportOptions: {columns:':visible'},
					   	/*	  createEmptyCells :true,
			   		  customize: function( xlsx ) {
		                var sheet = xlsx.xl.worksheets['sheet1.xml'];
		                $('row:first c', sheet).attr( 's', '42' );
		                $('c[r=A2] t', sheet).cell( 'Custom text' );
		            }*/
			   	  },
			      {
			   		  extend:    'pdfHtml5',
			   		  text:      '<i class="fa fa-file-pdf-o"></i> Pdf',
			   		  titleAttr: 'Pdf',
			   		  //exportOptions: {columns:':visible'},
			   		  //exportOptions: {columns: [ 0, 1, 2, 5 ]},
			   		  orientation: 'landscape',
			   		  pageSize: 'A4',
	     	   		  title :title,
	                }
			     ]
			   );
			  },//end of function
		  
		  getDTOptionBy4Params: function(scope,data,title,messageTop) {
		  		console.log("scope in service2222====>"+scope);
		  		sharedService.setData(scope);
		  		  return DTOptionsBuilder.fromFnPromise(function() {
					console.log("fileContent ====>" +data);
			        var defer = $q.defer();
			        defer.resolve(data);
			        return defer.promise;
			       }).withOption('responsive', true)
			      .withOption('autoWidth', false)
				 .withPaginationType('full_numbers')
				 .withDOM('frtip')
		         .withOption('createdRow', createdRow)
			     .withOption('deferRender', true)
			     .withBootstrap()
			     .withOption('scrollX', 'auto')      
				//.withOption('scrollCollapse', true)
			     .withButtons([
			   	  {
			   		  extend:    'colvis',
			   		  text:      '<i class="fa fa-colvis-o"></i> ColVis',
			   		  titleAttr: 'ColVis'
			   	  },
			   	  {
			   		  extend:    'print',
			   		  text:      '<i class="fa fa-print" aria-hidden="true"></i> Print',
			   		  titleAttr: 'Print'
			   	  },
			   	  {
			   		  extend:    'excelHtml5',
			   		  text:      '<i class="fa fa-file-text-o"></i> Excel',
			   		  titleAttr: 'Excel',
			   		  title :title,
			   		  messageTop:messageTop,
			   	  },
			      {
			   		  extend:    'pdfHtml5',
			   		  text:      '<i class="fa fa-file-pdf-o"></i> Pdf',
			   		  titleAttr: 'Pdf',
			   		  //exportOptions: {columns:':visible'},
			   		  orientation: 'landscape',
			   		  pageSize: 'A4',
	     	   		  title :title,
	     	   		  messageTop:messageTop,
	                }
			     ]
			   );
			  },//end of function
			  
			  getDTOptionBy2Params: function(scope,data) {
			  		console.log("scope in service 333====>"+scope);
			  		sharedService.setData(scope);
			  		  return DTOptionsBuilder.fromFnPromise(function() {
						console.log("fileContent 3333 ====>" +data);
				        var defer = $q.defer();
				        defer.resolve(data);
				        return defer.promise;
				       }).withOption('responsive', true)
				      .withOption('autoWidth', false)
					 .withPaginationType('full_numbers')
					 .withDOM('frtip')
			         .withOption('createdRow', createdRow)
				     .withOption('deferRender', true)
				     .withBootstrap()
				     
				  },//end of function
				  
				  getDTOptionByCustomRowBG: function(scope,data,isCustomRow) {
				  		console.log("scope in service====>"+scope);
				  		sharedService.setData(scope);
				  		  return DTOptionsBuilder.fromFnPromise(function() {
							console.log("fileContent ====>" +data);
					        var defer = $q.defer();
					        defer.resolve(data);
					        return defer.promise;
					       }).withOption('responsive', true)
					      .withOption('autoWidth', false)
						 .withPaginationType('full_numbers')
						 .withDOM('frtip')
				         .withOption('createdRow', createdRowCustom)
					     .withOption('deferRender', true)
					     .withBootstrap()
					     .withButtons([
						   	  {
						   		  extend:    'colvis',
						   		  text:      '<i class="fa fa-colvis-o"></i> ColVis',
						   		  titleAttr: 'ColVis'
						   	  },
						   	  {
						   		  extend:    'print',
						   		  text:      '<i class="fa fa-print" aria-hidden="true"></i> Print',
						   		  titleAttr: 'Print'
						   	  },
						   	  {
						   		  extend:    'excelHtml5',
						   		  text:      '<i class="fa fa-file-text-o"></i> Excel',
						   		  titleAttr: 'Excel',
						   		  title :'COR Report',
						   		  //messageTop:messageTop,
						   	  },
						      {
						   		  extend:    'pdfHtml5',
						   		  text:      '<i class="fa fa-file-pdf-o"></i> Pdf',
						   		  titleAttr: 'Pdf',
						   		  //exportOptions: {columns:':visible'},
						   		  orientation: 'landscape',
						   		  pageSize: 'A4',
				     	   		  title :'COR Report',
				     	   		 // messageTop:messageTop,
				                }
						     ]
						   );
					  },//end of function
				  
		  
  };//end of return
  
  function actionsDateFormat(data, type) {
	   	return $filter('date')(data, 'MM/dd/yyyy'); 
 };
 
  function createdRow(row, data, dataIndex) {
	  	$compile(angular.element(row).contents())(sharedService.getData());
   };
	   
   function createdRowCustom(row, data, dataIndex) {
	   var myString=data.resourceDetailVO.cmPercentage;
	   myString=myString.replace(/%$/, '');
	   if ( parseFloat(myString) < 40 ) {
           $('td', row).eq(9).addClass('highlight');
           $('td', row).addClass('danger');
       }
       $compile(angular.element(row).contents())(sharedService.getData());
	};
			   
}]);