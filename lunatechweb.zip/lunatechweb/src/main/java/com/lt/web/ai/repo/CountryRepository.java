package com.lt.web.ai.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.model.CountryEntity;

public interface CountryRepository extends JpaRepository<CountryEntity, Long>{
	 CountryEntity findById(Long id);
	 @Query("SELECT DISTINCT ce.name FROM CountryEntity ce WHERE UPPER(ce.name) like CONCAT(UPPER(?1),'%')")
	 List<String> findByNameStartingWithIgnoreCase(String name) throws LTException;
	 @Query("SELECT DISTINCT ce.code FROM CountryEntity ce WHERE UPPER(ce.code) like CONCAT(UPPER(?1),'%')")
	 List<String> findByCodeStartingWithIgnoreCase(String code) throws LTException;
	 CountryEntity findByCode(String code) throws LTException;
	 CountryEntity findByName(String name) throws LTException;
	 List<CountryEntity> findAllByOrderByIdAsc();

 }