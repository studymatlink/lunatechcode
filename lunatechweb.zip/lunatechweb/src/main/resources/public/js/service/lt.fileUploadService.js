'use strict';
app.factory('fileUploadService', ['$http','$q','commonutil',function($http, $q,commonutil,$rootScope) 
	{
	return{
		saveFileContent : function(fileContent,fileSaveMethod) {
			return commonutil.httpCall('./fileUpload/'+fileSaveMethod,'POST',{},fileContent);
		},
		
		getFileContent: function(file,fileUploadName,fileType) {
			   return commonutil.fileHttpCall('./fileUpload/getFileContent','POST',{fileUploadName:fileUploadName,fileType:fileType},file);
		},
		getDocFileContent: function(file,fileContentName) {
			   return commonutil.fileHttpCall('./fileUpload/getDocFileContent','POST',{fileContentName:fileContentName},file);
		},
		
		  
	};// end of return
}]);





