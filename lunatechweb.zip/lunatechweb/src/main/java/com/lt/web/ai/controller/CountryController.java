package com.lt.web.ai.controller;


import java.util.List;

/*import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.manager.CountryService;


@RestController
public class CountryController {
	
	@Autowired
	private	CountryService countryService;
	
	@GetMapping(value = "/country/getCountryNameStartsWith")
	public List<String> getCountryNameStartsWith(@RequestParam("data") String data) {
			System.out.println("getColtManagersNameStartsWith====>"+data);    
			try {
				return countryService.getCountryNameStartsWith(data);
			} catch (LTException e) {
				e.printStackTrace();
			}
			return null;
		
	}
	
	@GetMapping(value = "/country/getCountryCodeStartsWith")
	public List<String> getCountryCodeStartsWith(@RequestParam("data") String data) {
			System.out.println("getColtManagersNameStartsWith====>"+data);    
			try {
				return countryService.getCountryCodeStartsWith(data);
			} catch (LTException e) {
				e.printStackTrace();
			}
			return null;
		
	}
	
	
}
