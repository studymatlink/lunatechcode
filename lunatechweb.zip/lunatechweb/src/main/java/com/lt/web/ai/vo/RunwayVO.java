package com.lt.web.ai.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.poiji.internal.annotation.ExcelCell;

import groovy.transform.EqualsAndHashCode;
import lombok.Data;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown=true)
public class RunwayVO extends BaseVO{
	@ExcelCell(0) 
	private String id;
	@ExcelCell(1) 
	private String airport_ref;
	@ExcelCell(2) 
	private String airport_ident;
	@ExcelCell(3) 
	private String length_ft;
	@ExcelCell(4) 
	private String width_ft;
	@ExcelCell(5) 
	private String surface;
	@ExcelCell(6) 
	private String lighted;
	@ExcelCell(7)
	private String closed;
	@ExcelCell(8)
	private String le_ident;
	@ExcelCell(9)
	private String le_latitude_deg;
	@ExcelCell(10)
	private String le_longitude_deg;
	@ExcelCell(11)
	private String le_elevation_ft;
	@ExcelCell(12)
	private String le_heading_degT;
	@ExcelCell(13)
	private String le_displaced_threshold_ft;
	@ExcelCell(14)
	private String he_ident;
	@ExcelCell(15)
	private String he_latitude_deg;
	@ExcelCell(16)
	private String he_elevation_ft;
	@ExcelCell(17)
	private String he_heading_degT;
	@ExcelCell(18)
	private String he_displaced_threshold_ft;
	
}