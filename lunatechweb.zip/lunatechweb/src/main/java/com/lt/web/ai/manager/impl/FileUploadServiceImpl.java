
package com.lt.web.ai.manager.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lt.web.ai.dao.AirportDao;
import com.lt.web.ai.dao.CountryDao;
import com.lt.web.ai.dao.RunwayDao;
import com.lt.web.ai.excel.DocFileHandler;
import com.lt.web.ai.excel.ExcelFileHandler;
import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.manager.FileUploadService;
import com.lt.web.ai.vo.AirportVO;
import com.lt.web.ai.vo.CountryVO;
import com.lt.web.ai.vo.RunwayVO;


@Service("fileUploadService")
public class FileUploadServiceImpl implements FileUploadService {
	@Autowired
	private CountryDao countryDao;
	@Autowired
	private AirportDao airportDao;
	@Autowired
	private RunwayDao runwayDao;
	
	@Autowired
	private ExcelFileHandler excelFileHandler;
	
	@Autowired
	private DocFileHandler docFileHandler;
	
	@Override
	public List<?> getFileContent(File file,String fileUploadName,String fileType) {
		/*System.out.println("fileUploadName=====>"+fileUploadName);
		System.out.println("fileType=====>"+fileType);*/
		List<?> list = new ArrayList<>();
		if(fileType.equalsIgnoreCase("EXCEL")){
			if(fileUploadName.equalsIgnoreCase("COUNTRY")){
				list =(List<CountryVO>)excelFileHandler.readCountryExcel(file);
			}else if(fileUploadName.equalsIgnoreCase("AIRPORT")){
				list =(List<AirportVO>)excelFileHandler.readAirportExcel(file);
			}else if(fileUploadName.equalsIgnoreCase("RUNWAY")){
				list =(List<RunwayVO>)excelFileHandler.readRunwayExcel(file);
			}
			
		}
		return list;
	}
	
	@Override
	public String countryImport(List<CountryVO> countryVOs) {
		String message="Details Saved Successfully";
		try {
			countryDao.saveCountryData(countryVOs);
		} catch (LTException e) {
			e.printStackTrace();
			message="Some Problem Occured!!";
		}
		return message;
	}

	@Override
	public String airportImport(List<AirportVO> airportVOs) {
		String message="Details Saved Successfully";
		try {
			airportDao.saveAirportData(airportVOs);
		} catch (LTException e) {
			e.printStackTrace();
			message="Some Problem Occured!!";
		}
		return message;
	}

	@Override
	public String runwayImport(List<RunwayVO> runwayVOs) {
		String message="Details Saved Successfully";
		try {
			runwayDao.saveRunwayData(runwayVOs);
		} catch (LTException e) {
			e.printStackTrace();
			message="Some Problem Occured!!";
		}
		return message;
	}
	
	@Override
	public byte[] getDocFileContent(File file,String fileUploadName) {
		byte[] fileContent=null;
		fileContent =docFileHandler.readDocFile(file);
		return fileContent;
	}

}
