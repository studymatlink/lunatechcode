'use strict';
app.factory('commonService', ['$http', '$q','commonutil', function($http, $q,commonutil) {
  return {
	  	  getSelectList: function(selectListName) {
	  		  return commonutil.httpCall('./'+selectListName+'/','GET',{},'');
		  },//end of function
  
  };//end of return
	  
}]);
