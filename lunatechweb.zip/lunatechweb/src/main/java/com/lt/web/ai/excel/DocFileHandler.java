/**
 * 
 */
package com.lt.web.ai.excel;

import java.io.File;
import java.io.FileInputStream;

import org.springframework.stereotype.Component;

/**
 * @author aranjan5
 *
 */
@Component("docFileHandler")
public class DocFileHandler {
	public  byte[] readDocFile(File file){
		FileInputStream fileInputStream = null;
	     byte[] bytesArray = null;
	     bytesArray = new byte[(int) file.length()];
		 try {
		      fileInputStream = new FileInputStream(file);
		     //convert file into array of bytes
		      fileInputStream.read(bytesArray);
		      fileInputStream.close();
	        } catch (Exception e) {
		     e.printStackTrace();
	        }
		 return bytesArray;
	}
	
}	