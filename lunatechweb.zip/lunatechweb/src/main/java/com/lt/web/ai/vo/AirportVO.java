package com.lt.web.ai.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.poiji.internal.annotation.ExcelCell;

import groovy.transform.EqualsAndHashCode;
import lombok.Data;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown=true)
public class AirportVO extends BaseVO{
	@ExcelCell(0) 
	private String id;
	@ExcelCell(1) 
	private String ident;
	@ExcelCell(2) 
	private String type;
	@ExcelCell(3) 
	private String name;
	@ExcelCell(4) 
	private String latitude_deg;
	@ExcelCell(5) 
	private String longitude_deg;
	@ExcelCell(6) 
	private String elevation_ft;
	@ExcelCell(7)
	private String continent;
	@ExcelCell(8)
	private String iso_country;
	@ExcelCell(9)
	private String iso_region;
	@ExcelCell(10)
	private String municipality;
	@ExcelCell(11)
	private String scheduled_service;
	@ExcelCell(12)
	private String gps_code;
	@ExcelCell(13)
	private String iata_code;
	@ExcelCell(14)
	private String local_code;
	@ExcelCell(15)
	private String home_link;
	@ExcelCell(16)
	private String wikipedia_link;
	@ExcelCell(17)
	private String keywords;
}