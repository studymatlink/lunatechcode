/**
 * 
 */
package com.lt.web.ai.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.lt.web.ai.manager.FileUploadService;
import com.lt.web.ai.util.FileUtility;
import com.lt.web.ai.vo.AirportVO;
import com.lt.web.ai.vo.CountryVO;
import com.lt.web.ai.vo.FileUploadVO;
import com.lt.web.ai.vo.RunwayVO;


@RestController
public class FileUploadController {
	@Autowired
	private FileUploadService fileUploadService;
		
	@RequestMapping(value = "/fileUpload/getFileContent", method = RequestMethod.POST)
	public List<?>  getFileContent(@RequestParam("file") MultipartFile multipartFile,@RequestParam("fileUploadName") String fileUploadName,@RequestParam("fileType") String fileType) {
		try {
			File file =FileUtility.convertMultipartToOutputStream(multipartFile);
			return fileUploadService.getFileContent(file,fileUploadName,fileType);
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}
	
	@RequestMapping(value = "/fileUpload/getDocFileContent", method = RequestMethod.POST)
	public FileUploadVO  getDocFileContent(@RequestParam("file") MultipartFile multipartFile,@RequestParam("fileContentName") String fileContentName,HttpServletRequest httpServletRequest) {
		FileUploadVO fileUploadVO=new FileUploadVO();
		try {
			File file =FileUtility.convertMultipartToOutputStream(multipartFile);
			byte[] fileContents=fileUploadService.getDocFileContent(file,fileContentName);
			httpServletRequest.getSession().setAttribute("fileContents", fileContents);
			fileUploadVO.setFileContent(fileContents);
			fileUploadVO.setFileContentName(fileContentName);
			fileUploadVO.setFileName(multipartFile.getOriginalFilename());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return fileUploadVO;
	}
	
	@RequestMapping(value = "/fileUpload/saveCountryImport", method = RequestMethod.POST)
	public void saveCountryImport(@RequestBody List<CountryVO> countryVOs)  {
		fileUploadService.countryImport(countryVOs);
	}
	
	@RequestMapping(value = "/fileUpload/saveAirportImport", method = RequestMethod.POST)
	public void saveAirportImport(@RequestBody List<AirportVO> airportVOs)  {
		fileUploadService.airportImport(airportVOs);
	}
	
	@RequestMapping(value = "/fileUpload/saveRunwayImport", method = RequestMethod.POST)
	public void saveRunwayImport(@RequestBody List<RunwayVO> runwayVOs)  {
		fileUploadService.runwayImport(runwayVOs);
	}
	
	
}