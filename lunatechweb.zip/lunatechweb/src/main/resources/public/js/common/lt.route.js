app.config(function($routeProvider){
	$routeProvider
	 .when("/", {
	        templateUrl : "html/home/dashboard.html",
	        controller: 'DashboardController',
	        controllerAs: "dc"
	})
   
    .when('/import/countryFileUpload',{
        templateUrl: 'html/import/countryImport.html',
    	controller: 'FileUploadController',
        controllerAs: "fuc"
    })
    
    .when('/import/airportFileUpload',{
        templateUrl: 'html/import/airportImport.html',
    	controller: 'FileUploadController',
        controllerAs: "fuc"
    })
    
    .when('/import/runwayFileUpload',{
        templateUrl: 'html/import/runwayImport.html',
    	controller: 'FileUploadController',
        controllerAs: "fuc"
    })
    
/*    .otherwise(
    { 
    	//redirectTo: '/forgetPassword'
    	 templateUrl: 'html/home/pageNotFound.html',
    });*/
});

