package com.lt.web.ai.controller;


import java.util.List;

/*import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.manager.AirportService;
import com.lt.web.ai.manager.CountryService;
import com.lt.web.ai.vo.CountVO;
import com.lt.web.ai.vo.QueryVO;


@RestController
public class AirportController {
	
	@Autowired
	private	AirportService airportService;
	
	@Autowired
	private	CountryService countryService;
	
	@GetMapping(value = "/airport/getAirports")
	public List<QueryVO> getAirports(@RequestParam("countryName") String countryName,@RequestParam("countryCode") String countryCode) {
			String country=null;
			try {
				if(StringUtils.isEmpty(countryCode)) {
					country=countryService.getCountryDetailsByName(countryName).getCode();
				}else {
					country=countryCode;
				}
				return airportService.getAirportsWithRunwayByCountryCode(country);
			} catch (LTException e) {
				e.printStackTrace();
			}
			return null;
		
	}
	
	@GetMapping(value = "/airport/getTop10CountryWithHighestAirportCount")
	public List<CountVO> getTop10CountryWithHighestAirportCount() {
		try {
			return airportService.getTop10CountryWithHighestAirportCount();
			
		} catch (LTException e) {
			e.printStackTrace();
		}	
		return null;
	}
	
	@GetMapping(value = "/airport/getTop10CountryWithLowestAirportCount")
	public List<CountVO> getTop10CountryWithLowestAirportCount() {
		try {
			return airportService.getTop10CountryWithLowestAirportCount();
		} catch (LTException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
}
