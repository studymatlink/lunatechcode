'use strict';
var app = angular.module('ltapp', ['ngRoute','ngResource','ngMessages','checklist-model','datatables','datatables.bootstrap','ui.bootstrap','datatables.buttons','ngAnimate','chart.js']);

