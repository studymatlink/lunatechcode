package com.lt.web.ai.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import groovy.transform.EqualsAndHashCode;
import lombok.Data;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown=true)
public class QueryVO extends BaseVO{
	private AirportVO airportVO;
	private List<RunwayVO> runwayVOs;
	
}