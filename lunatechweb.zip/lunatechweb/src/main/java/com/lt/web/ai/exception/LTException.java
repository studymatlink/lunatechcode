package com.lt.web.ai.exception;

public class LTException extends Exception {

	/**
	 * Unique ID for Serialized object
	 */
	private static final long serialVersionUID = 4657491283614755649L;

	
	private String errorCode;
	
	public LTException(String msg) {
		super(msg);
	}

	public LTException(String msg,String errorCode, Exception t) {
		super(msg, t);
		this.errorCode=errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}
	

}