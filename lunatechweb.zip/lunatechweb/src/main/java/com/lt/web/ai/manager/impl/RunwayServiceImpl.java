
package com.lt.web.ai.manager.impl;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.lt.web.ai.dao.CountryDao;
import com.lt.web.ai.dao.RunwayDao;
import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.manager.CountryService;
import com.lt.web.ai.manager.RunwayService;
import com.lt.web.ai.model.RunwayEntity;
import com.lt.web.ai.vo.AirportVO;
import com.lt.web.ai.vo.CountVO;
import com.lt.web.ai.vo.CountryVO;
import com.lt.web.ai.vo.RunwayVO;


@Service("runwayService")
public class RunwayServiceImpl implements RunwayService{
	
	@Autowired
    private RunwayDao runwayDao;

	@Override
	public RunwayVO getRunwayDetailsById(Long id) throws LTException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RunwayVO> getAllRunwayDetails() throws LTException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getRunwayNameStartsWith(String coltManagersName) throws LTException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RunwayVO> getRunwayDetailsByAirportRefAndIdent(String airportRef, String airportIdent)	throws LTException {
		return runwayDao.getRunwayDetailsByAirportRefAndIdent(airportRef, airportIdent);
	}

	@Override
	public List<String> getDistinctRunwaySurfaceDetailsByAirportRef(List<String> airportRef)	throws LTException {
		return runwayDao.getDistinctRunwaySurfaceDetailsByAirportRef(airportRef);
	}

	@Override
	public List<CountVO> getTop10CommonRunwayIdentification() throws LTException {
		// TODO Auto-generated method stub
		
		
		List<CountVO> countVOs=new ArrayList<>();
		List<Object[]>  list=runwayDao.getTop10CommonRunwayIdentification();
		for (Object[] object : list) {
				CountVO countVO=new CountVO();
				countVO.setRunwayIdent(String.valueOf(object[0]));
				countVOs.add(countVO);
		}
		return countVOs;
	}
	

	
}
