package com.lt.web.ai.model;




import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode
@Data
@Entity
@Table(name="AIRPORT")
public class AirportEntity implements Serializable{
	private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "id", updatable = false, nullable = false)

	private Long id;
 
	private String ident;

	private String type;

	private String name;

	private String latitude_deg;

	private String longitude_deg;

	private String elevation_ft;

	private String continent;

	//private String iso_country;
	private String isoCountry;

	private String iso_region;

	private String municipality;

	private String gps_code;

	private String iata_code;

	private String local_code;

	private String home_link;

	private String wikipedia_link;

	private String keywords;
	
}
