package com.lt.web.ai.model;




import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode
@Data
@Entity
@Table(name="COUNTRY")
public class CountryEntity implements Serializable{
	private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "id", updatable = false, nullable = false)
	private Long id;

	private String code;

	private String name;

	private String continent;

	private String wikipedia_link;

	private String keywords;
	
}
