app.directive("selectList", function(commonService,$compile) {
    return {
       	restrict: 'EA',
        scope:{
        	//modelName :'@modelName',
        	modelName:'=',
        	fieldRequired :'@fieldRequired',
        	cssClass :'@cssClass',
        	fieldName :'@fieldName',
        	selectName :'@selectName',
        	functionName :'='
        },//isolated scope
        templateUrl : "html/common/select.html",
        controller: function ($scope) {
        	console.log("modelName in HTML====>"+$scope.modelName);
        	if(!angular.isUndefined($scope.selectName)){
            	commonService.getSelectList($scope.selectName).then(
            	        function(result) {
            	        	if(result.length>0){
            	        		 $scope.selectList = result;
            	        	}
            	       	 }, 
            	         function(error) {
            	            alert("Error: No data returned");
            	        }
            	  );
        	}else{
        		console.log("selectName attribute not defined in HTML");
        	}
          },
        // controllerAs: "cc",
         link: function(scope, elm, attrs, ctrl) {

        },
     
    };
});

app.directive("selectListCustom", function(commonService,$compile) {
    return {
       restrict: 'EA',
       link: function(scope, elm, attrs, ctrl) {
        	 commonService.getSelectList(attrs.id).then(
         	        function(result) {
         	        	if(result.length>0){
         	        		scope.selectList = result;
         	        	}
         	       	 }, 
         	         function(error) {
         	            alert("Error: No data returned");
         	        }
         	  );
        },
    };
});
app.directive('autoComplete', function($timeout) {
    return function(scope, iElement, iAttrs) {
            iElement.autocomplete({
                source: scope[iAttrs.uiItems],
                select: function() {
                    $timeout(function() {
                      iElement.trigger('input');
                    }, 0);
                }
            });
    };
});

app.directive('textLength', function () {
	  return {
	    restrict: "A",
	    require: 'ngModel',
	    link: function (scope, element, attrs, ngModel) {
	      attrs.$set("ngTrim", "false");
	      var limitLength = parseInt(attrs.textLength, 10);// console.log(attrs);
	      scope.$watch(attrs.ngModel, function(newValue) {
	      // if(ngModel.$viewValue !== undefined){
	    	if(!angular.isUndefined(ngModel.$viewValue)){	   
		        if(ngModel.$viewValue.length>limitLength){
			          ngModel.$setViewValue( ngModel.$viewValue.substring(0, limitLength ) );
			          ngModel.$render();
			        }  
	       }	  

	      });
	    }
	  };
	});

app.directive('capitalizeInputText', function() {
    return {
      require: 'ngModel',
      link: function(scope, element, attrs, modelCtrl) {
          var capitalizeInputText = function(inputText) {
        	  if (inputText !== undefined) {
        		  var capitalizedValue = inputText.toUpperCase();
        		  if (capitalizedValue !== inputText) {
        			  modelCtrl.$setViewValue(capitalizedValue);
        			  modelCtrl.$render();
	               }
        	  } 
        	 return capitalizedValue;
        }
         modelCtrl.$parsers.push(capitalizeInputText);
        capitalizeInputText(scope[attrs.ngModel]); 
      }
    };
  });
