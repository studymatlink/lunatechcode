package com.lt.web.ai.model;




import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.Type;

import com.poiji.internal.annotation.ExcelCell;

import lombok.Data;
import lombok.EqualsAndHashCode;


@EqualsAndHashCode
@Data
@Entity
@Table(name="RUNWAY")
public class RunwayEntity implements Serializable{
	private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "id", updatable = false, nullable = false)
	private Long id;

	private String airportRef;

	private String airportIdent;

	private String length_ft;

	private String width_ft;

	private String surface;

	private String lighted;

	private String closed;

	private String le_ident;

	private String le_latitude_deg;

	private String le_longitude_deg;

	private String le_elevation_ft;

	private String le_heading_degT;

	private String le_displaced_threshold_ft;

	private String he_ident;

	private String he_latitude_deg;

	private String he_elevation_ft;

	private String he_heading_degT;

	private String he_displaced_threshold_ft;
	
	
}
