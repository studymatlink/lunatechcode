/**
 * 
 */
package com.lt.web.ai.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.springframework.web.multipart.MultipartFile;

/**
 * @author aranjan5
 *
 */
public class FileUtility {
	public static File convertMultipartToOutputStream(MultipartFile multipartFile) throws IOException
	{    
	    File file = new File(multipartFile.getOriginalFilename());
	    System.out.println("multipartFile.getOriginalFilename()====>"+multipartFile.getOriginalFilename());
	    file.createNewFile(); 
	    FileOutputStream fos = new FileOutputStream(file); 
	    fos.write(multipartFile.getBytes());
	    fos.close(); 
	    return file;
	}
}
