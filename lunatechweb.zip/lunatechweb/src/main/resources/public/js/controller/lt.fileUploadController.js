'use strict';
app.controller('FileUploadController',['$scope','fileUploadService',function($scope,fileUploadService) {
	 $scope.content = {};
	 $scope.resizeMode = "OverflowResizer";
	// $scope.dtInstance = {};
	 var vm = this;
     //$scope.authorized = false;
     $scope.UploadFile = function() {
    	var file =$scope.content[$scope.modelName];
        if (file) {
        	fileUploadService.getFileContent(file,$scope.fileContentName,$scope.fileType).then(function(result) {
        		//console.log("result data " +result);
        		if(result){
        			  $scope.fileContent=result;
        			  saveFileContent();
        		}
   		}, function(error) {
   			alert("Error: No data returned" + error);
   			
   		});
        }
        else {
            $scope.Message = "No data found";
        }
    };
    
    /* saveFileContent .start */
    function saveFileContent() {
		 fileUploadService.saveFileContent($scope.fileContent,$scope.fileSaveMethod).then(function(result) {
	      	  $scope.showFileData = false;
	      	  $scope.successFlag = true;
	      	  $scope.content[$scope.modelName]='';
	      	  $scope.fileContent={};
		}, function(error) {
			 $scope.failureFlag = true;
			console.log("Error: No data returned " + error);
		});
	};
	/* saveFileContent .end */
    
	
	
}]);