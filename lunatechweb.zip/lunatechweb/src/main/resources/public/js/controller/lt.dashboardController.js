'use strict';
app.controller('DashboardController',['$scope','dashboardService','DTOptionsBuilder','DTColumnBuilder','$q','$compile','popupUtil','commonDTService',function($scope,dashboardService,DTOptionsBuilder,DTColumnBuilder,$q,$compile,popupUtil,commonDTService) {
	
	$scope.runways = {};
	
    $scope.getAction = function() {
    	console.log("======getAction=====>");
     	  if(angular.equals($scope.dc.userAction,'REPORT')){
     		 console.log("======REPORT=====>");
     		$scope.getTop10CountryWithHighestAirportCount();
     		$scope.getTop10CountryWithLowestAirportCount();
     		$scope.getTop10CommonRunwayIdentification();
     	  }
    }; 

	$scope.getCountryNameStartsWith = function(data) {
     	  //console.log("data:"+data);
     	  return dashboardService.getCountryNameStartsWith(data);
    }; 
    
    $scope.getCountryCodeStartsWith = function(data) {
     	  //console.log("data:"+data);
     	  return dashboardService.getCountryCodeStartsWith(data);
    }; 
	
    $scope.getAirports = function() {
   	  if(angular.equals($scope.dc.countryCode,null)){
   		return dashboardService.getAirports($scope.dc.countryName,'');
   	  }else{
   		return dashboardService.getAirports('',$scope.dc.countryCode);  
   	  }
  }; 
  
  
  $scope.getAirports = function() {
	$scope.showAirportDetails = true;
	$scope.dtColumns='';
   	var countryName='';
   	var countryCode='';
    if(angular.equals($scope.dc.countryCode,null)){
    	countryName=$scope.dc.countryName;
   	  }else{
   		countryCode=$scope.dc.countryCode;  
   	  }

   	dashboardService.getAirports(countryName,countryCode).then(
		function(data) {
			 loadAirportTemplateDT(data);
		}, function(error) {
			console.log("Error: No data returned" + error);
			$scope.showFileData = false;
			
		});
	};
	
	function loadAirportTemplateDT(data){
		$scope.dtOptions=commonDTService.getDTOptionBy3Params($scope,data,'Airport');
		$scope.dtColumns = [
				  DTColumnBuilder.newColumn(null).withTitle('Runway_Details').notSortable().renderWith(actionsHtml),
				  DTColumnBuilder.newColumn('airportVO.id').withTitle('id'),
				  DTColumnBuilder.newColumn('airportVO.ident').withTitle('ident'),
				  DTColumnBuilder.newColumn('airportVO.type').withTitle('type'),
				  DTColumnBuilder.newColumn('airportVO.name').withTitle('name'),
				  DTColumnBuilder.newColumn('airportVO.latitude_deg').withTitle('latitude_deg'),
				  DTColumnBuilder.newColumn('airportVO.longitude_deg').withTitle('longitude_deg'),
				  DTColumnBuilder.newColumn('airportVO.elevation_ft').withTitle('elevation_ft'),
				  DTColumnBuilder.newColumn('airportVO.continent').withTitle('continent'),
				  DTColumnBuilder.newColumn('airportVO.iso_country').withTitle('iso_country'),
				  DTColumnBuilder.newColumn('airportVO.iso_region').withTitle('iso_region'),
				  DTColumnBuilder.newColumn('airportVO.municipality').withTitle('municipality'),
				  DTColumnBuilder.newColumn('airportVO.gps_code').withTitle('gps_code'),
				  DTColumnBuilder.newColumn('airportVO.iata_code').withTitle('iata_code'),
				  DTColumnBuilder.newColumn('airportVO.local_code').withTitle('local_code'),//blank
				  DTColumnBuilder.newColumn('airportVO.home_link').withTitle('home_link'),
		          DTColumnBuilder.newColumn('airportVO.wikipedia_link').withTitle('wikipedia_link'),
		          DTColumnBuilder.newColumn('airportVO.keywords').withTitle('keywords'),
		          DTColumnBuilder.newColumn(null).withTitle('Runway_Details').notSortable().renderWith(actionsHtml)
		          
		];
	};
  
	function actionsHtml(data, type, full, meta) {
		 var runways =data.runwayVOs;
  		 $scope.runways[data.airportVO.id] =runways;	
  		 if(runways.length>0){
  			 return '<button class="btn btn-success" ng-click="getRunwayDetail(runways['+data.airportVO.id+'])"><i class="fa fa-info"></i></button>'; 
  		 }else{
  			return '<button class="btn btn-success"><i class="fa fa-ban" style="bold;color:red"><b>No Runway</b></i></button>'; 
  		 }
	   
  		
	};
  
   $scope.getRunwayDetail = function (data) {
 	   	 console.log('opening pop up data'+angular.toJson(data));
 	   	 popupUtil.openPopUpWithScopeAndSize('./html/home/runwayDetail.html','DashboardModalController',data,$scope,'app-modal-window');
	 };
	 
	 $scope.getTop10CountryWithHighestAirportCount = function() {
		 $scope.showMaxAirportReport = true;
		   	dashboardService.getTop10CountryWithHighestAirportCount().then(
				function(data) {
					 loadTop10CountryWithHighestAirportCountTemplateDT(data);
				}, function(error) {
					console.log("Error: No data returned" + error);
					$scope.showMaxAirportReport = false;
					
				});
			};
			
	 $scope.getTop10CountryWithLowestAirportCount = function() {
		   	$scope.showMinAirportReport = true;
		   	dashboardService.getTop10CountryWithLowestAirportCount().then(
				function(data) {
					 loadTop10CountryWithLowestAirportCount(data);
				}, function(error) {
					console.log("Error: No data returned" + error);
					$scope.showMinAirportReport = false;
					
				});
			};
			
	$scope.getTop10CommonRunwayIdentification = function() {
	   	$scope.showCommonRIReport = true;
	   	dashboardService.getTop10CommonRunwayIdentification().then(
			function(data) {
				loadTop10CommonRunwayIdentification(data);
			}, function(error) {
				console.log("Error: No data returned" + error);
				$scope.showCommonRIReport = false;
				
			});
		};		
	function loadTop10CountryWithHighestAirportCountTemplateDT(data){
		$scope.dtOptionsMax=commonDTService.getDTOptionBy3Params($scope,data,'Country_Airport');
		$scope.dtColumnsMax = [
				  DTColumnBuilder.newColumn('country').withTitle('Country'),
				  DTColumnBuilder.newColumn('count').withTitle('Airport_Count'),
				  DTColumnBuilder.newColumn('runwaySurface').withTitle('Type of runways'),
		];
	};
	
	function loadTop10CountryWithLowestAirportCount(data){
		$scope.dtOptionsMin=commonDTService.getDTOptionBy3ParamsNoScroll($scope,data,'Country_Airport');
		$scope.dtColumnsMin = [
				  DTColumnBuilder.newColumn('country').withTitle('Country'),
				  DTColumnBuilder.newColumn('count').withTitle('Airport_Count'),
				  DTColumnBuilder.newColumn('runwaySurface').withTitle('Type of runways'),
		];
	};
	
	function loadTop10CommonRunwayIdentification(data){
		$scope.dtOptionsCommon=commonDTService.getDTOptionBy3ParamsNoScroll($scope,data,'Runway_Identifications');
		$scope.dtColumnsCommon = [
				  DTColumnBuilder.newColumn('runwayIdent').withTitle('Runway Identifications'),
		];
	};
	
}]);