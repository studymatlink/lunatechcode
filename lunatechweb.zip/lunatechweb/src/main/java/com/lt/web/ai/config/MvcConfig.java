package com.lt.web.ai.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
public class MvcConfig extends WebMvcConfigurerAdapter{	

	
    @Override
    public void addResourceHandlers(final ResourceHandlerRegistry registry) {
//        registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
          registry.addResourceHandler ("/webjars/**").addResourceLocations ("classpath:/META-INF/resources/webjars/").resourceChain(false);;
    }
    
	/*By default spring boot looks thymeleaf template files inside template folder.If you had put templates files other
	than template folder then you need to give view resolver  path of template file */
/*	@Override
	public void configureViewResolvers(ViewResolverRegistry registry) {
		registry.jsp("/views/", ".html");
	}*/
    
  
	@Override
    public void addViewControllers(ViewControllerRegistry registry) {
		registry.addRedirectViewController("/", "/home").setContextRelative(true);
		//registry.addViewController("/").setViewName("home");
        registry.addViewController("/home").setViewName("home");
    }
	

    
    

}
