package com.lt.web.ai.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.poiji.internal.annotation.ExcelCell;

import groovy.transform.EqualsAndHashCode;
import lombok.Data;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown=true)
public class FileUploadVO extends BaseVO{
	private Long id;
	private String fileName;
	private String fileContentName;
	private byte[] fileContent;
	
	
    
}