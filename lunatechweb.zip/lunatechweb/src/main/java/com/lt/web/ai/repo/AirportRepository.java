package com.lt.web.ai.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.model.AirportEntity;
import com.lt.web.ai.vo.CountVO;

public interface AirportRepository extends JpaRepository<AirportEntity, Long>{
	 AirportEntity findById(Long id);
	 List<AirportEntity> findAllByOrderByIdAsc();
	 List<AirportEntity> findByIsoCountry(String isoCountry) throws LTException;
	 //@Query("select new com.lt.web.ai.vo.CountVO(a.iso_country,count(*)as airport_nos) from airport a group by a.iso_country ORDER BY airport_nos DESC LIMIT 10")
	 @Query(value="select  iso_Country,count(*)as airport_nos from Airport  group by iso_Country ORDER BY airport_nos DESC LIMIT 10", nativeQuery=true)
	 List<Object[]> findTop10CountryWithHighestAirportCount() throws LTException;
	// @Query("select new com.lt.web.ai.vo.CountVO(a.iso_country,count(*)as airport_nos) from airport a group by a.iso_country ORDER BY airport_nos ASC LIMIT 10")
	 @Query(value="select  iso_Country,count(*)as airport_nos from Airport  group by iso_Country ORDER BY airport_nos ASC LIMIT 10", nativeQuery=true)
	 List<Object[]> findTop10CountryWithLowestAirportCount() throws LTException;

 }