'use strict';
app.factory('sharedService', ['$http', '$q','commonutil', function($http, $q,commonutil,$rootScope) {
	this.resData = {};

	// share serviceofSow data * .start/
	return {
	   setData : function set(data) {
			this.resData = data;
		},
		getData : function get() {
			return this.resData;
		},
  	};
	// share serviceofSow data * .end/

	  
}]);
