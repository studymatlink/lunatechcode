/**
 * 
 */
package com.lt.web.ai.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lt.web.ai.vo.SelectListVO;


/**
 * @author aranjan5
 *
 */
@RestController
public class CommonController {

	@RequestMapping(value="/userAction",method = RequestMethod.GET)
	public List<SelectListVO> getUserAction(){
		String[] data={"Query","Report"};
		return this.getData(data);
	}
	
	private List<SelectListVO> getData(String[] data){
		List<SelectListVO> list=new ArrayList<>();
		for (String  str : data) {
			SelectListVO selectListVO=new SelectListVO();
			selectListVO.setId(str);
			selectListVO.setName(str);
			list.add(selectListVO);
		}
		return list;
	}
	
	
	
}

