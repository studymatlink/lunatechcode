'use strict';
app.factory('popupUtil', ['$uibModal', '$q', function($uibModal, $q) {
  return {

      openPopUp:function (templatePath,controllerName,resultData) {
		    console.log('opening pop up in util');
		    var modalInstance = $uibModal.open({
			     templateUrl:templatePath,
	        	 controller:controllerName ,
	             resolve: {
	                    	detail: function() {
	        						 return resultData;
	        					   }
	                	 }
	        	 });
	          },
	          
	          openPopUpWithScope:function (templatePath,controllerName,resultData,scope) {
	  		    console.log('===open PopUp With Scope in util====');
	  		    var modalInstance = $uibModal.open({
	  			     templateUrl:templatePath,
	  	        	 controller:controllerName ,
	  	             resolve: {
	  	                    	detail: function() {
	  	                    			 return resultData;
	  	        					   },
  	        					 scopeDetail: function() {
  	        						 return scope;
  	        					   }	   
	  	                	 }
	  	        	 });
	  	          },
	  	          
	  	        openPopUpWithScopeAndSize:function (templatePath,controllerName,resultData,scope,className) {
		  		    console.log('open PopUp With Scope in util');
		  		    var modalInstance = $uibModal.open({
		  			     templateUrl:templatePath,
		  	        	 controller:controllerName ,
		  	             windowClass:className,
		  	             resolve: {
		  	                    	detail: function() {
		  	                    			 return resultData;
		  	        					   },
	  	        					 scopeDetail: function() {
	  	        						 return scope;
	  	        					   }	   
		  	                	 }
		  	        	 });
		  	          },
  };//end of return
}]);
