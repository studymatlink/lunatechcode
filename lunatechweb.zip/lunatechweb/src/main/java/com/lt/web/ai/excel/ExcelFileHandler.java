/**
 * 
 */
package com.lt.web.ai.excel;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.lt.web.ai.vo.AirportVO;
import com.lt.web.ai.vo.CountryVO;
import com.lt.web.ai.vo.RunwayVO;
import com.poiji.internal.Poiji;

/**
 * @author aranjan5
 *
 */
@Component("excelFileHandler")
public class ExcelFileHandler {
	DateFormat dateFormat = new SimpleDateFormat("dd-mm-yyyy");
	public  List<AirportVO> readAirportExcel(File file){
		List<AirportVO> records=new ArrayList<>();
		try {
			records = Poiji.fromExcel(file, AirportVO.class);
			//System.out.println(records.size());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return records;
	}
	
	public  List<CountryVO> readCountryExcel(File file){
		List<CountryVO> records=new ArrayList<>();
		try {
			records = Poiji.fromExcel(file, CountryVO.class);
			//System.out.println(records.size());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return records;
	}
	
	public  List<RunwayVO> readRunwayExcel(File file){
		List<RunwayVO> records=new ArrayList<>();
		try {
			records = Poiji.fromExcel(file, RunwayVO.class);
			//System.out.println(records.size());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return records;
	}
}	