/**
 * 
 */
package com.lt.web.ai.vo;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

/**
 * @author aranjan5
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown=true)
public class BaseVO {
	private String createdBy;
    private String createdOn;
    private String modifiedBy;
    private Date modifiedOn;
}    