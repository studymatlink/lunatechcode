package com.lt.web.ai.dao;





import java.util.List;

import com.lt.web.ai.exception.LTException;
import com.lt.web.ai.model.AirportEntity;
import com.lt.web.ai.vo.AirportVO;
import com.lt.web.ai.vo.CountVO;


public interface AirportDao {
	boolean saveAirportData(List<AirportVO> sowContents) throws LTException;
	List<AirportVO> getAirportsByCountryCode(String countryCode) throws LTException;
	List<Object[]> getTop10CountryWithHighestAirportCount() throws LTException;
	List<Object[]> getTop10CountryWithLowestAirportCount() throws LTException;


}
